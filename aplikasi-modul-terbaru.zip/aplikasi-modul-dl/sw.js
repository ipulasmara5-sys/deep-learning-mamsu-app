/* ============================================================
   SERVICE WORKER — agar aplikasi bisa dipakai OFFLINE di HP
   ============================================================ */
const CACHE = 'modul-dl-v2';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-512.png',
  './xlsx.full.min.js'
];

// Saat diinstall: simpan semua file aplikasi ke cache
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

// Saat diaktifkan: hapus cache lama, ambil alih langsung
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Strategi: cache-first, fallback jaringan, lalu simpan ke cache
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        const copy = response.clone();
        caches.open(CACHE).then((cache) => cache.put(event.request, copy));
        return response;
      }).catch(() => caches.match('./index.html'));
    })
  );
});
